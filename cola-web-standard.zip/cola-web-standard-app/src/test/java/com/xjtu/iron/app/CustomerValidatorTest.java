package com.xjtu.iron.app;

import org.junit.Test;

public class CustomerValidatorTest {

    @Test
    public void testValidation(){

    }
}
