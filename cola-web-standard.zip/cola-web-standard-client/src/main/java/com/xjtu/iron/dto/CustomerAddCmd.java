package com.xjtu.iron.dto;

import com.xjtu.iron.dto.data.CustomerDTO;
import lombok.Data;

@Data
public class CustomerAddCmd{

    private CustomerDTO customerDTO;

}
