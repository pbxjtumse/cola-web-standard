package com.xjtu.iron.dto.event;

/**
 * @author niexiaolong
 * @date 2019/4/16
 */
public class DomainEventConstant {

	public static final String CUSTOMER_CREATED_TOPIC = "CRM_CUSTOMER_CREATED_DOMAIN_EVENT_TOPIC";

}
