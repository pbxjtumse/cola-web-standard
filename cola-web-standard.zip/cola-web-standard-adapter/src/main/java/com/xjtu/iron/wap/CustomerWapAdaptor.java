package com.xjtu.iron.wap;

/**
 * Customer Wap Adaptor
 *
 * WAP : Wireless Application Protocol)
 *
 * @author Frank Zhang
 * @date 2020-10-27 8:03 PM
 */
public class CustomerWapAdaptor {
}
