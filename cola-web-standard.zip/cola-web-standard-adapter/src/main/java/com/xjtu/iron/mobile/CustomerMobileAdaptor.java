package com.xjtu.iron.mobile;

/**
 * Customer Mobile Adaptor
 *
 *
 * @author Frank Zhang
 * @date 2020-10-27 8:04 PM
 */
public class CustomerMobileAdaptor {
}
