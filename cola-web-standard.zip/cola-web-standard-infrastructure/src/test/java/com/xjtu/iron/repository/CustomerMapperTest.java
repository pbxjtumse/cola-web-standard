package com.xjtu.iron.repository;


public class CustomerMapperTest {

    public void testFindByID() {
        System.out.println("Write your test here");
    }
}
