package com.xjtu.iron.customer.gateway;

import com.xjtu.iron.domain.customer.Credit;
import com.xjtu.iron.domain.customer.gateway.CreditGateway;

public class CreditGatewayImpl implements CreditGateway {
    public Credit getCredit(String customerId){
      return null;
    }
}
