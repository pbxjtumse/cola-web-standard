package com.xjtu.iron.order;

public class OrderGatewayImpl{

}
