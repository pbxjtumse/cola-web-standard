package com.xjtu.iron.cola.web.handler;

public interface RawMessageHandler {
}
