package com.xjtu.iron.cola.web.execution.impl.consumer;

public class SingleThreadExecution {
}
