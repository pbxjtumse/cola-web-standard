package com.xjtu.iron.cola.web.enums;

/**
 * 消费状态枚举
 * @author pbxjtu
 */
public enum ConsumeResultEnum {
    SUCCESS,
    RETRY,
    FAIL
}
