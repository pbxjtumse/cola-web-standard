package com.xjtu.iron.cola.web.execution;

/**
 *
 * @author pbxjtu
 */
public interface ConsumeExecution {

}
