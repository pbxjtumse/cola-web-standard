package com.xjtu.iron.cola.web.client;

public class Subscription {

    private String destination;
    private String consumerGroup;
}

