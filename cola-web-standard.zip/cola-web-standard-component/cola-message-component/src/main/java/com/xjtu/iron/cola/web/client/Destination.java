package com.xjtu.iron.cola.web.client;

public class Destination {
    String topic;
    String tag;
    String routingKey;
}
