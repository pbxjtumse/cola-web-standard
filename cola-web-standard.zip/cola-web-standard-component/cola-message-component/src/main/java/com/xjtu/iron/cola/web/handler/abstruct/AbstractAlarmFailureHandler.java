package com.xjtu.iron.cola.web.handler.abstruct;

public abstract class AbstractAlarmFailureHandler {
    protected abstract void sendAlarm();
}
