package com.xjtu.iron.domain.customer.domainservice;

//The domain's ability can also be placed here
public class CreditChecker{

}
