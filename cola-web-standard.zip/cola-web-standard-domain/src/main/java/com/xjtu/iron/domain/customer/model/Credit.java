package com.xjtu.iron.domain.customer.model;

import com.alibaba.cola.domain.Entity;
import lombok.Data;

@Data
@Entity
public class Credit{
    
}
