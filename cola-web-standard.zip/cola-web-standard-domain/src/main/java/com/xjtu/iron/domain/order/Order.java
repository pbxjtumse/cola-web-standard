package com.xjtu.iron.domain.order;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Order{
    private String userId;
    private String skuId;
}
