package com.xjtu.iron.domain.customer;

/**
 * SourceType
 *
 * @author Frank Zhang
 * @date 2018-01-08 11:09 AM
 */
public enum SourceType {
    BIZ_ONE, //From biz one
    BIZ_TWO; //From biz two
}
