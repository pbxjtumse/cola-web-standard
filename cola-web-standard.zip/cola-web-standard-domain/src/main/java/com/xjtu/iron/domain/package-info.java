/**
 * This is domain module, the core business logic is implemented here.
 * 
 * @author fulan.zjf
 */
package com.xjtu.iron.domain;