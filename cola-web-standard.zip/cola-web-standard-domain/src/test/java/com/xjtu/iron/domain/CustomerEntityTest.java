package com.xjtu.iron.domain;


public class CustomerEntityTest {

    public void testCustomerConflict() {
        System.out.println("Please mock gatewayimpl, test pure Domain Knowledge");
    }
}
